# A UI for mewsfeed based on Vue

## Run dev server
```sh
npm i
npm run start
```

## Lint
```sh
npm run lint
```
<template>
  <div class="text-base-content font-content font-normal animate-pulse">
    <div class="flex items-center space-x-4">
      <IconPersonCircle class="text-base-300 w-8 h-8 p-0 m-0" />

      <div class="h-2 bg-base-300 rounded-full w-32"></div>
    </div>
  </div>
</template>

<script setup lang="ts">
import IconPersonCircle from "~icons/ion/person-circle";
</script>

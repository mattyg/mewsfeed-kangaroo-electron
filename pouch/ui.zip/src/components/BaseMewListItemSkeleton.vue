<template>
  <div class="flex justify-start items-start space-x-2 px-2 animate-pulse">
    <IconPersonCircle class="text-base-300 w-14 h-14 p-0 m-0" />
    <div class="flex-1">
      <div class="flex justify-between items-center">
        <div class="flex items-center w-full space-x-2">
          <div class="h-2.5 bg-base-300 rounded-full w-32"></div>
          <div class="h-2.5 bg-base-200 rounded-full w-24"></div>
        </div>
        <div class="h-2.5 bg-base-200 rounded-full w-32"></div>
      </div>

      <div class="flex flex-col w-full space-y-2 my-4">
        <div class="h-1.5 bg-base-200 rounded-full w-5/6"></div>
        <div class="h-1.5 bg-base-200 rounded-full w-3/4"></div>
        <div class="h-1.5 bg-base-200 rounded-full w-5/6"></div>
        <div class="h-1.5 bg-base-200 rounded-full w-3/4"></div>
      </div>

      <div class="flex justify-between items-center">
        <div class="flex justify-start items-center space-x-2">
          <div class="bg-base-200 rounded-full w-4 h-4"></div>
          <div class="bg-base-200 rounded-full w-4 h-4"></div>
          <div class="bg-base-200 rounded-full w-4 h-4"></div>
          <div class="bg-base-200 rounded-full w-4 h-4"></div>
        </div>
        <div class="flex justify-start items-center space-x-2">
          <div class="bg-base-200 rounded-full w-4 h-4"></div>
          <div class="bg-base-200 rounded-full w-4 h-4"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import IconPersonCircle from "~icons/ion/person-circle";
</script>

/**
 * @public
 */
export const SignalType = {
    App: "App",
    System: "System",
};

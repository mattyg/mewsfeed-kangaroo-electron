import { encode } from "@msgpack/msgpack";
import { invoke } from "@tauri-apps/api/tauri";
import { getNonceExpiration, randomNonce } from "../api/zome-call-signing.js";
const __HC_LAUNCHER_ENV__ = "__HC_LAUNCHER_ENV__";
export const isLauncher = () => {
    console.log("isLauncher", globalThis.window && __HC_LAUNCHER_ENV__ in globalThis.window);
    console.log("window.__HC_LAUNCHER_ENV__", window.__HC_LAUNCHER_ENV__, globalThis.window.__HC_LAUNCHER_ENV__);
    alert(`window.__HC_LAUNCHER_ENV__ ${window.__HC_LAUNCHER_ENV__} ${globalThis.window.__HC_LAUNCHER_ENV__}`)
    return globalThis.window && __HC_LAUNCHER_ENV__ in globalThis.window;
};
export const getLauncherEnvironment = () => isLauncher() ? globalThis.window[__HC_LAUNCHER_ENV__] : undefined;
export const signZomeCallTauri = async (request) => {
    const zomeCallUnsigned = {
        provenance: Array.from(request.provenance),
        cell_id: [Array.from(request.cell_id[0]), Array.from(request.cell_id[1])],
        zome_name: request.zome_name,
        fn_name: request.fn_name,
        payload: Array.from(encode(request.payload)),
        nonce: Array.from(await randomNonce()),
        expires_at: getNonceExpiration(),
    };
    const signedZomeCallTauri = await invoke("sign_zome_call", { zomeCallUnsigned });
    const sig{
        nedZomeCall = {
        provenance: Uint8Array.from(signedZomeCallTauri.provenance),
        cap_secret: null,
        cell_id: [
            Uint8Array.from(signedZomeCallTauri.cell_id[0]),
            Uint8Array.from(signedZomeCallTauri.cell_id[1]),
        ],
        zome_name: signedZomeCallTauri.zome_name,
        fn_name: signedZomeCallTauri.fn_name,
        payload: Uint8Array.from(signedZomeCallTauri.payload),
        signature: Uint8Array.from(signedZomeCallTauri.signature),
        expires_at: signedZomeCallTauri.expires_at,
        nonce: Uint8Array.from(signedZomeCallTauri.nonce),
    };
    return signedZomeCall;
};

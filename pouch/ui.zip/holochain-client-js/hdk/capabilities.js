/**
 * @public
 */
export var GrantedFunctionsType;
(function (GrantedFunctionsType) {
    GrantedFunctionsType["All"] = "All";
    GrantedFunctionsType["Listed"] = "Listed";
})(GrantedFunctionsType || (GrantedFunctionsType = {}));
